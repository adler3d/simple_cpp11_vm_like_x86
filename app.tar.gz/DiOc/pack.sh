unlink app.tar.gz
tar cvzf app.tar.gz ../DiOc
